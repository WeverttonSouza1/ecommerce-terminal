package domain;

public interface Exibivel { // interface
	String exibir();
}
