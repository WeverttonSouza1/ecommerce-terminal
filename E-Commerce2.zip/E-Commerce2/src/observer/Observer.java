package observer;

public interface Observer {
    void update(NotificacaoProduto notificacao);
}
