package state;

public interface PedidoState {
    void exibirStatus();
}
