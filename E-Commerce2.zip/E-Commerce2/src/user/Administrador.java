package user;

public class Administrador extends Usuario {
    // para caso precise adicionar ações especificas para o administrador
}
